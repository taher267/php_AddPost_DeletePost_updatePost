
<?php 
session_start();
include'connect.php';
?>

<?php 
if(isset($_REQUEST["id"])&& isset($_REQUEST["sName"])&& isset($_REQUEST["saGe"])&& isset($_REQUEST["sRoll"])){
	$Id=$_REQUEST["id"];
	$fulNme=$_REQUEST["sName"];
	$stuAge=$_REQUEST["saGe"];
	$stuRoll=$_REQUEST["sRoll"];
	$Qry="UPDATE students SET fulName='$fulNme',age='$stuAge',roll='$stuRoll' WHERE id='$Id'";
	$ruQry=$connect->query($Qry);
	if($ruQry=true){
		$_SESSION["Updated"]=1;
		header("Location:index.php");
	}else{
		header("Location:edit.php?err=1");
	}
}



 ?>