<?php include'header.php'; ?>
<?php 
if(isset($_REQUEST["id"])){
  $Id=$_REQUEST["id"];
  $checkQry="SELECT * FROM students WHERE id='$Id'";
  $runQry=$connect->query($checkQry);
  $myData=$runQry->fetch_assoc();
  
}
             ?>
<div class="container">
	<div class="row">
		<div class="col-md-3"></div>
		<div class="col-md-6">
			<h2>Registion Form</h2>
	     <form action='edit_core.php?id=<?php  echo $myData["id"];?>' method="POST">
	     	<table class="table table-striped table-dark">
          <tbody>
            
            
            <tr>
              <td>
                <input type="text" value="<?php  echo $myData["fulName"];?>" required name="sName" placeholder="Student's Full Name" class="col-md-12">
              </td>
            </tr>
            <tr>
              <td>
                <input type="text" value="<?php  echo $myData["age"];?>" required name="saGe" placeholder="Student's age"class="col-md-12">
              </td>
            </tr>
            <tr>
              <td><input type="text"value="<?php  echo $myData["roll"];?>" required name="sRoll" placeholder="Student's Roll"class="col-md-12"></td>
            </tr>
            <tr>
              <td><input type="submit" value="UPDATE" class="col-md-12"></td>
            </tr>
          </tbody>
        </table>
	     </form>
</div>
		<div class="col-md-3">
   
    </div>
</div>
<?php require_once('footer.php'); ?>