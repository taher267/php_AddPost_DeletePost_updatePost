<?php include'header.php'; 

?>
<div class="container">
	<div class="row clearfix">
		<div class="col-md-3">
			<a href="signup.php" class="btn btn-info">New Students</a>
		</div>
		<div class="col-md-9">
			<h2>Bismillair Rohmanir Rohim</h2>
			
		</div>
		
	</div>
</div>

<div class="container">
	<div class="row">
		
	


</div>
</div>


























<?php include'footer.php';

 ?>