<?php include'header.php'; 


?>
<div class="container">
	<div class="row clearfix">
		<div class="col-md-3">
			<a href="#" class="btn btn-info">New Students</a>
		</div>
		<div class="col-md-9">
			<h2>STUDENT INFORMATION</h2>
			<table border="1" class="table table-striped table-dark">
				<thead>
					<tr>
						<th>Name</th>
						<th>Age</th>
						<th>Roll</th>
					</tr>
				</thead>
				<tbody>
					<?php 
					if(isset($_REQUEST["id"])){
						$Id=$_REQUEST["id"];
					
						$selectStu="SELECT * FROM students WHERE id='$Id'";
						 $runquery=$connect->query($selectStu);
						if($runquery==true){
							$myData=$runquery->fetch_assoc() ?>
								
								<tr>
									<td><?php  echo $myData["fulName"];?></td>
									<td><?php  echo $myData["age"];?></td>
									<td><?php  echo $myData["roll"];?></td>
								</tr>


						<?php 	}}?>



						 
					
				</tbody>
			</table>
		</div>
		
	</div>
</div>

<div class="container">
	<div class="row">
		
	


</div>
</div>


























<?php include'footer.php'; ?>