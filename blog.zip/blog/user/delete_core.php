
<?php 
session_start();
include'connect.php';
if(isset($_REQUEST["id"])){
	$Id=$_REQUEST["id"];
	$Qry="DELETE FROM students WHERE id='$Id'";
	$ruQry=$connect->query($Qry);
	if($ruQry=true){
		
		$_SESSION['Data_del']=1;
		header("Location:index.php");
	}else{
		header("Location:index.php?Data_not_deleted!");
	}
}



 ?>