<?php 
require('connect.php');
session_start();
 ?>

<?php


if(isset($_REQUEST["sName"])&&isset($_REQUEST["saGe"])&&isset($_REQUEST["sRoll"])&&isset($_REQUEST["sMail"])&&isset($_REQUEST["sPwd"])){
$sg_name=$_REQUEST["sName"];
$sg_age=$_REQUEST["saGe"];
$sg_roll=$_REQUEST["sRoll"];
$sg_mail=$_REQUEST["sMail"];
$sg_Pwd=$_REQUEST["sPwd"];
$chackMail="SELECT * FROM students WHERE mailAdr='$sg_mail'";
$mailQry=$connect->query($chackMail);
$rowCont=$mailQry->num_rows;

if($rowCont==1){
	$_SESSION['err']=1;
	header("Location:signup.php?err=1");
}else{

	$selectStu="INSERT INTO students (fulName,age,roll,mailAdr,pass) VALUES('$sg_name','$sg_age','$sg_roll','$sg_mail','$sg_Pwd')";
	$runquery=$connect->query($selectStu);
	//$runquery=mysqli_query($connect,$selectStu);
	if($runquery==true){
		$_SESSION['success']=1;
		header("Location:index.php");
	}
}

}
?>