<?php 
require('connect.php');
 ?>
<?php include'header.php'; ?>
<div class="container">
	<div class="row">
		<div class="col-md-3"></div>
		<div class="col-md-6">
			<?php
			if(isset($_REQUEST["mailAddr"])&&isset($_REQUEST["pwd"])){
			$lgMail=$_REQUEST["mailAddr"];
			$lgPwd=$_REQUEST["pwd"];
			$selectStu="SELECT * FROM students WHERE mailAdr='$lgMail' AND pass='$lgPwd'";
			$runQry=$connect->query($selectStu);
			if($runQry==true){
				while($studentData=$runQry->fetch_assoc()){
				echo $studentData["fulName"];
				echo "<br/>";
				echo $studentData["roll"];
				
			}
			}


			}
			?>
		</div>
		<div class="col-md-3"><a class="btn btn-danger" href="logout.php">Logout</a></div>
</div></div>
<?php include'footer.php'; ?>