<?php include'header.php'; ?>
<div class="container">
	<div class="row">
		<div class="col-md-3"></div>
		<div class="col-md-6">
			<h2>Registion Form</h2>
	     <form action="login_core.php" method="POST">
	     	<table class="table table-striped table-dark">
          <tbody>
            <tr>
              <td>
                <input type="text" required name="mailAddr" placeholder="Mail address"class="col-md-12">
              </td>
            </tr>
            <tr>
              <td><input type="password" required name="pwd" placeholder="Password"class="col-md-12"></td>
            </tr>
            <tr>
              <td><input type="submit" value="LOGIN" class="col-md-12"></td>
            </tr>
          </tbody>
        </table>
	     </form>
</div>
		<div class="col-md-3">
   
    </div>
</div>
<?php require_once('footer.php'); ?>