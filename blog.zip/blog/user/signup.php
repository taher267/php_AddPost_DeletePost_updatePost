<?php include'header.php'; ?>
<div class="container">
	<div class="row">
		<div class="col-md-3"></div>
		<div class="col-md-6">
			<h2>Registion Form</h2>
       <?php

        if(isset($_SESSION['err'])){?>
            <div class="alert alert-danger" role="alert">
              Already have Ac
          </div>
       
         <?php  } ?>
	     <form action="signup_core.php" method="POST">
	     	<table class="table table-striped table-dark">
          <tbody>
            <tr>
              <td>
                <input type="text" required name="sName" placeholder="Student's Full Name" class="col-md-12">
              </td>
            </tr>
            <tr>
              <td>
                <input type="text" required name="saGe" placeholder="Student's age"class="col-md-12">
              </td>
            </tr>
            <tr>
              <td>
                <input type="text" required name="sRoll" placeholder="Student's Roll"class="col-md-12">
              </td>
            </tr>
            <tr>
              <td>
                <input type="text" required name="sMail" placeholder="Email Address"class="col-md-12">
              </td>
            </tr>
            <tr>
              <td>
                <input type="text" required name="sPwd" placeholder="Password" class="col-md-12">
              </td>
            </tr>
            <tr>
              <td><input type="submit" value="SIGNUP" class="col-md-12"></td>
            </tr>
          </tbody>
        </table>
	     </form>
</div>
		<div class="col-md-3">
   
    </div>
</div>
<?php require_once('footer.php'); 

unset($_SESSION['err']);
?>