<?php 

include'../include/header.php';

?>
<a href="#" class="btn btn-success">Detail Post</a>

<div class="contant">

<table class="table table-striped">
<tbody>
	<?php 
	if(isset($_REQUEST["id"])){
		$userId=$_REQUEST["id"];

		$sql="SELECT * FROM posts WHERE id=$userId";
		$result=$connect->query($sql);

		$sqlJoin="SELECT posts.*,categories.title as catId FROM posts
		JOIN categories ON posts.categoryID=categories.id WHERE posts.id=$userId";
		 $joinResult=$connect->query($sqlJoin);
		 $joinRow=$joinResult->fetch_assoc();
		

		if($result==true){
			$row=$result->fetch_assoc(); ?>
			<tr>
				<td><h1><?php echo $joinRow["title"]; ?></h1></td>
			</tr>
			<tr>
			<td><?php echo $joinRow["description"]; ?></td>
			<td><?php 
				// $idForCate= $row["categoryID"];
				// $cateSql="SELECT * FROM categories WHERE id=$idForCate";
				// $catResult=$connect->query($cateSql);
				// $cateData=$catResult->fetch_assoc();
				$chackUncategory= $joinRow["catId"];
				if($chackUncategory>0){
					echo $joinRow["catId"];;
				}else{
					echo "Uncategory";
				}

			?></td>
			</tr>
			
			<tr>
			<td><img width="100%" src="../uploads/<?php echo $joinRow["image"];?>"></td>
			</tr>
					
	<?php }}?>

			</tbody>
				
	</table>


</div>

































<?php 
include'../include/footer.php';
unset($_SESSION['success']);
unset($_SESSION['delet']);
?>