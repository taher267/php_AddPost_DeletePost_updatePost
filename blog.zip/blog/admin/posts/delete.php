<?php 
session_start();
include'../include/connect.php';
?>

	<?php 
	if(isset($_REQUEST["id"])){
	$delId=	$_REQUEST["id"];
	$chkSql="SELECT * FROM posts WHERE id='$delId'";
	$chkResult=$connect->query($chkSql);
	$chkData=$chkResult->fetch_assoc();
	$file_loc="../uploads/".$chkData["image"];
	$chkImg=file_exists($file_loc);
	$dataDelited=unlink($file_loc);
		
		$delSql="DELETE FROM posts WHERE id='$delId'";
		$delResult=$connect->query($delSql);
		if($delResult==true){
			$_SESSION["delet"]=1;
			header("Location:index.php");
		}
	

	}


	// if()){
	// 	$delId=$_REQUEST["id"];
	// 	$delSql="DELETE FROM posts WHERE id='$delId'";
	// 	$delResult=$connect->query($delSql);
	// 	if($delResult==true){
	// 		header("Location:index.php");
	// 	}
	// }






	?>



















