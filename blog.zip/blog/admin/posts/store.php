<?php 
session_start();
include('../include/connect.php');
?>
<?php 
if(isset($_REQUEST["pstTitle"])&&isset($_REQUEST["pstDesc"])&&isset($_REQUEST["categori"])&&isset($_FILES["featureImg"])){
	$postTitle=htmlentities(ltrim($_REQUEST["pstTitle"]));
	$postDescip=htmlentities(ltrim($_REQUEST["pstDesc"]));
	$category=htmlentities(ltrim($_REQUEST["categori"]));
	$featureTmp=$_FILES["featureImg"]["tmp_name"];
	//$emptyFile=strlen($featureTmp);
	$dbimg=uniqid().".jpg";
	$location='../uploads/'.$dbimg;

	if (empty($_FILES["featureImg"]["name"])){	//or (Not OR gate) $emptyFile == 0
		$insSql="INSERT INTO posts (title,categoryID,description) VALUES ('$postTitle','$category','$postDescip')";
			
	}else{
	$fileUpld=move_uploaded_file($featureTmp,$location);
	$insSql="INSERT INTO posts (title,categoryID,description,image) VALUES ('$postTitle','$category','$postDescip','$dbimg')";

	}
	$insResult=$connect->query($insSql);
	if($insResult==true){
		$_SESSION['success']=1;
		header("Location:index.php");
}


}
?>





















