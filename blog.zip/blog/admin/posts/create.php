<?php 
include'../include/header.php';
?>
<?php 
	$turnSql="SELECT * FROM categories";
	$result=$connect->query($turnSql);
	


 ?>
<a href="index.php" class="btn btn-success">Back</a>
<div class="contant">
	<h1>Add a new post</h1>
	<form method="POST" action="store.php" enctype="multipart/form-data">
		  <div class="form-group">
		    <label for="Title">Title</label>
		    <input type="text" name="pstTitle" required class="form-control" id="cateTitle">
		</div>
		<div class="input-group form-group">
		  <div class="input-group-prepend">
		    <span class="input-group-text" id="inputGroupFileAddon01">Featured</span>
		  </div>
		  <div class="custom-file">
		    <input type="file" class="custom-file-input" name="featureImg">
		    <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
		  </div>
		</div>
		<div class="form-group">
		    <label for="Description">Description</label>
		    <textarea type="text"name="pstDesc" rows="10" required class="form-control" id="cateTitle" ></textarea>
		</div>
		
		<div class="form-group">
		    <select name="categori" id=""class="form-control">
		    	<?php 
		    		while($categoryTrun=$result->fetch_assoc()){?>
		    			<option value="<?php echo $categoryTrun["id"]; ?>" >
		    				<?php echo $categoryTrun["title"]; ?>
		    			</option><?php }?>
		    	
		    </select>
		</div>
		  <button type="submit" class="btn btn-primary">Add Post</button>
</form>



</div>




































<?php 
include'../include/footer.php';
?>






















