<?php 
include'../include/header.php';
?>
<?php 
	if(isset($_REQUEST["id"])){
		$requistId=$_REQUEST["id"];
		$reqSql="SELECT * FROM posts WHERE id='$requistId'";
		$result=$connect->query($reqSql);
		$reqData=$result->fetch_assoc();
	//For category selectron
	$turnSql="SELECT * FROM categories";
	$result=$connect->query($turnSql);
	}

 ?>
<a href="" class="btn btn-success">Back</a>
<div class="contant">
	<h1>Update post</h1>
	<form method="POST" enctype="multipart/form-data" action="update.php?id=<?php echo $reqData["id"];?> ">

		  <div class="form-group">
		    <label for="Title">Title</label>
		    <input type="text" name="editTitle" value="<?php echo $reqData["title"]; ?> " class="form-control" id="editInp"  />
		  </div>
		 <div class="input-group form-group">
		  <div class="input-group-prepend">
		    <span class="input-group-text" id="inputGroupFileAddon01">Featured</span>
		  </div>
		  <div class="custom-file">
		    <input type="file" class="custom-file-input" name="featureImg">
		    <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
		  </div>

		</div>
		<div class="input-group form-group">
		<img width="20%" src="<?php echo "../uploads/".$reqData["image"]; ?> " alt="">
	</div>
		  <div class="form-group">
		    <label for="Description">Description</label>
		    <textarea type="text" name="editDesc" rows="10" required class="form-control" id="cateTitle" ><?php echo $reqData["description"]; ?> </textarea>
		</div>
		<div class="form-group">
		    <select name="categori" id=""class="form-control">
		    	<?php 
		    		while($categoryTrun=$result->fetch_assoc()){?>
						<?php 
							if($reqData["categoryID"]==$categoryTrun["id"]){?>
							<option selected value="<?php echo $categoryTrun["id"]; ?>" >
							<?php echo $categoryTrun["title"]; ?></option>
						<?php }else{?>
		    			<option value="<?php echo $categoryTrun["id"]; ?>" >
							<?php echo $categoryTrun["title"]; ?></option>
		    		<?php }}?>
		    	
		    </select>
		</div>
		  <button type="submit" class="btn btn-primary">Update</button>
</form>



</div>




































<?php 
include'../include/footer.php';
?>






















