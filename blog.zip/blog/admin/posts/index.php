<?php 
//session_start();
//include'../connect.php';
include'../include/header.php';

?>
<a href="create.php" class="btn btn-success">+ Add A Post</a>
<?php 
	if(isset($_SESSION['success'])){ ?>
	<a href="create.php" class="btn btn-info"><?php echo "Post success!"; ?></a>
	<?php }
	
	elseif(isset($_SESSION['delet'])){?>
		<a href="create.php" class="btn btn-danger"><?php echo "Post Deleted"; ?></a>
	<?php }elseif(isset($_SESSION['updated'])){?>
		<a href="create.php" class="btn btn-primary"><?php echo "Post Updated"; ?></a>
	<?php }?>
<div class="contant">

<table class="table table-striped">

	<thead>
		<tr>
			<th>ID</th>
			<th>Title</th>
			<th>Description</th>
			<th>Category</th>
			<th>Feature</th>
			
			<th>
				Action
			</th>
		</tr>
	</thead>
	<tbody>
		
	<?php 
		$sql="SELECT * FROM posts";
		$result=$connect->query($sql);

		

		if($result==true){
			while($row=$result->fetch_assoc()){ ?>
			<tr>
			<td><?php echo $row["id"]; ?></td>
			<td><?php echo $row["title"]; ?></td>
			<td><?php echo $row["description"]; ?></td>
			<td><?php $idForCate= $row["categoryID"];
			
				$cateSql="SELECT * FROM categories WHERE id=$idForCate";
				$catResult=$connect->query($cateSql);
				$cateData=$catResult->fetch_assoc();
				$chkID=$cateData["id"];
				
				if($chkID>0){
					echo $cateData["title"];;
				}else{
					echo "Uncategory";
				}

			?></td>



			<td><img width="100px" src="../uploads/<?php echo $row["image"];?>"></td>
			<td>
			<a href="view.php?id=<?php echo$row["id"]; ?>" class="btn btn-sm btn-primary">View</a>
			<a href="edit.php?id=<?php echo $row["id"]; ?>" class="btn btn-sm btn-success">Edit</a>
			<a onclick="return confirm('Are you Sure?')" href="delete.php?id=<?php echo $row["id"]; ?>" class="btn btn-sm btn-danger">Delete</a>
			</td>
			</tr>
					
	<?php }}?>

			</tbody>
				
	</table>


</div>

































<?php 
include'../include/footer.php';
unset($_SESSION['success']);
unset($_SESSION['delet']);
unset($_SESSION['updated']);
?>