<?php 
session_start();
include'../include/connect.php';
?>
<?php 
if(isset($_REQUEST["id"])){
$editId=$_REQUEST["id"];
$postTitle=$_REQUEST["editTitle"];
$postDisc=$_REQUEST["editDesc"];
$category=$_REQUEST["categori"];


$sqlJoin="SELECT posts.*,categories.title as catId FROM posts
JOIN categories ON posts.categoryID=categories.id WHERE posts.id=$editId";
$joinResult=$connect->query($sqlJoin);
$joinRow=$joinResult->fetch_assoc();
$insSql="UPDATE posts SET title='$postTitle',description='$postDisc',categoryID='$category'";
if( !empty( $_FILES["featureImg"]["name"] ) ){
	$featureTmp=$_FILES["featureImg"]["tmp_name"];
	$dbimg=uniqid().".jpg";
	$location='../uploads/'.$dbimg;
	
	if(!empty($joinRow["image"]) && file_exists('../uploads/'.$joinRow["image"])){
		unlink('../uploads/'.$joinRow["image"]);
	}
$insSql.=",image='$dbimg'";
 move_uploaded_file($featureTmp, $location);
}


$insSql.="WHERE id='$editId'";
$insResult=$connect->query($insSql);
if($insResult==true){
	$_SESSION["updated"]=1;
	header("Location:index.php");
}
 
}
?>






















