<?php 
include'include/header.php';
?>
<div class="contant">
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eaque explicabo placeat natus adipisci unde tenetur, exercitationem saepe enim aspernatur quasi maxime laboriosam quod dignissimos praesentium rerum voluptatibus reprehenderit repudiandae odit.</p><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eaque explicabo placeat natus adipisci unde tenetur, exercitationem saepe enim aspernatur quasi maxime laboriosam quod dignissimos praesentium rerum voluptatibus reprehenderit repudiandae odit.</p><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eaque explicabo placeat natus adipisci unde tenetur, exercitationem saepe enim aspernatur quasi maxime laboriosam quod dignissimos praesentium rerum voluptatibus reprehenderit repudiandae odit.</p><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eaque explicabo placeat natus adipisci unde tenetur, exercitationem saepe enim aspernatur quasi maxime laboriosam quod dignissimos praesentium rerum voluptatibus reprehenderit repudiandae odit.</p><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eaque explicabo placeat natus adipisci unde tenetur, exercitationem saepe enim aspernatur quasi maxime laboriosam quod dignissimos praesentium rerum voluptatibus reprehenderit repudiandae odit.</p>

</div>








<?php 
include'include/footer.php';
?>






















