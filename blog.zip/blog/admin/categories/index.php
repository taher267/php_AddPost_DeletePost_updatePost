<?php 
include'../include/header.php';

?>
<a href="create.php" class="btn btn-success">+ Add Category</a>
<div class="contant">
<table class="table table-striped">

	<thead>
		<tr>
			<th>ID</th>
			<th>Title</th>
			<th>
				Action
			</th>
		</tr>
	</thead>
	<tbody>
	<?php 
		$sql="SELECT * FROM categories";
		$result=$connect->query($sql);
		if($result==true){
			while($row=$result->fetch_assoc()){ ?>
			<tr>
			<td><?php echo $row["id"]; ?></td>
			<td><?php echo $row["title"]; ?></td>
			<td>
			<a href="edit.php?id=<?php echo $row["id"]; ?>" class="btn btn-sm btn-primary">Edit</a>

			<a onclick="return confirm('Are you Sure?')" href="delete.php?id=<?php echo $row["id"]; ?>" class="btn btn-sm btn-danger">Delete</a>
			</td>
			</tr>
					
	<?php }}?>
	

			</tbody>
				
	</table>


</div>

































<?php 
include'../include/footer.php';
?>