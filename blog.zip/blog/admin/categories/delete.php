<?php 
include'../include/header.php';
?>
<a href="index.php" class="btn btn-success">Back</a>
<div class="contant">
	<h1>Deleta The cartegory</h1>
<?php 
if(isset($_REQUEST["id"])){
	$delId=$_REQUEST["id"];
	$delSql="DELETE FROM categories WHERE id='$delId'";
	$delResult=$connect->query($delSql);
	if($delResult==true){
		header("Location:index.php");
	}
}






	?>

</div>




































<?php 
include'../include/footer.php';
?>






















