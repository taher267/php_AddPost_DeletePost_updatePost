<?php 
session_start();
include'../include/connect.php';
?>
<?php 
if(isset($_REQUEST["id"])){
$catryTitle=$_REQUEST["editTitle"];
$editId=$_REQUEST["id"];
$chkSql="SELECT * FROM categories WHERE title='$catryTitle'";
$chkResult=$connect->query($chkSql);
$rowCont=$chkResult->num_rows;
if($rowCont>=1){
	echo "More Data";
}elseif ($rowCont ===0) {
	$insSql="UPDATE categories SET title='$catryTitle' WHERE id='$editId'";
	$insResult=$connect->query($insSql);
	if($insResult==true){	
	$_SESSION['inserted']=1;
	header("Location:index.php");






}}}



// if($rowCont >1){
// 	$_SESSION['exist_ctary']=1;
// 	header("Location:create.php");	
// }elseif($rowCont===1){

	
// }


?>
























