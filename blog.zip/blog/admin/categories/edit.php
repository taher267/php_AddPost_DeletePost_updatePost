<?php 
include'../include/header.php';
?>
<?php 
	if(isset($_REQUEST["id"])){
		$requistId=$_REQUEST["id"];
		$reqSql="SELECT * FROM categories WHERE id='$requistId'";
		$result=$connect->query($reqSql);
		$reqData=$result->fetch_assoc();
		
	}

 ?>
<a href="" class="btn btn-success">Back</a>
<div class="contant">
	<h1>Edit Category</h1>
	<form method="POST" action="update.php?id=<?php echo $reqData["id"];?> ">
		  <div class="form-group">
		    <label for="Title">Title</label>
		    <input type="text" name="editTitle" value="<?php echo $reqData["title"]; ?> " class="form-control" id="editInp"  />
		   </div>
		  <button type="submit" class="btn btn-primary">Submit</button>
</form>



</div>




































<?php 
include'../include/footer.php';
?>






















