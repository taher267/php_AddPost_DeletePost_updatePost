<?php 
include'../include/header.php';
?>
<a href="index.php" class="btn btn-success">Back</a>
<div class="contant">
	<h1>Add a new category</h1>
	<form method="POST" action="store.php">
		  <div class="form-group">
		    <label for="Title">Title</label>
		    <input type="text" required class="form-control" id="cateTitle" name="catyTitle">
		</div>
		  <button type="submit" class="btn btn-primary">Submit</button>
</form>



</div>




































<?php 
include'../include/footer.php';
?>






















