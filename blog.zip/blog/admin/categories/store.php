<?php 
session_start();
include('../include/connect.php');
?>
<?php 
if(isset($_REQUEST["catyTitle"])){
$catryTitle=$_REQUEST["catyTitle"];
$chkSql="SELECT * FROM categories WHERE title='$catryTitle'";
$chkResult=$connect->query($chkSql);
$rowCont=$chkResult->num_rows;

if($rowCont > 0){
	$_SESSION['exist_ctary']=1;
	header("Location:create.php");	
}elseif($rowCont===0){
	$insSql="INSERT INTO categories (title) VALUES ('$catryTitle')";
	$insResult=$connect->query($insSql);
	if($insResult==true){
		$_SESSION['inserted']=1;
		header("Location:index.php");
	}
}


}

?>





















