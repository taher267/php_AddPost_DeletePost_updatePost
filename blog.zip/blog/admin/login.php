<?php require_once('include/header.php');?>

<div class="container">
	<div class="row">
		<h1> You Are not eligible to Signup or Login in Admin Panel</h1>
		<p>Just You Can Post Add, delete update</p>
	</div>
</div>
<?php require_once('include/footer.php');?>